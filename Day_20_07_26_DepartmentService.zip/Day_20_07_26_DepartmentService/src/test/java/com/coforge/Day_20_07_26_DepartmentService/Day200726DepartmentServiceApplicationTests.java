package com.coforge.Day_20_07_26_DepartmentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day200726DepartmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
