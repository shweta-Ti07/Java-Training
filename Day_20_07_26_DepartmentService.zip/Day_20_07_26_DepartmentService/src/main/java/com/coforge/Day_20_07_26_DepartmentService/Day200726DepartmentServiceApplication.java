package com.coforge.Day_20_07_26_DepartmentService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day200726DepartmentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day200726DepartmentServiceApplication.class, args);
	}

}
