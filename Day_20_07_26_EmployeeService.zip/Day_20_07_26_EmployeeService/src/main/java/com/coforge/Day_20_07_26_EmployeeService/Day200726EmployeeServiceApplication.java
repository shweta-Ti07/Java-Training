package com.coforge.Day_20_07_26_EmployeeService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day200726EmployeeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day200726EmployeeServiceApplication.class, args);
	}

}
